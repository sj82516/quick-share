## Quick Share
This is chrome extension project.    
Quick share current link to facebook and line. Support auto paste selected text.   

## Install and Usage
![](./intro-images/intro-1.png)
![](./intro-images/intro-2.png)

## TODO
Directly share to some people.